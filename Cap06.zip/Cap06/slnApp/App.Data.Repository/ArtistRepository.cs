﻿using App.Data.DataAccess;
using App.Data.Repository.Interface;
using App.Entities.Base;
using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace App.Data.Repository
{
    public class ArtistRepository : IArtistRepository,
                                IDisposable
    {
        protected readonly DbContext _context;

        public ArtistRepository(DbContext context)
        {
            this._context = context;
        }


        public int Add(Artist entity)
        {
            var result = 0;

            _context.Set<Artist>().Add(entity);
            _context.SaveChanges();

            result = entity.ArtistId;

            return result;
        }

        public int Count()
        {
            return _context.Set<Artist>().Count();
        }

        public void Dispose()
        {
            _context.Dispose();
        }

        public List<Artist> GetAll()
        {
            return _context.Set<Artist>().ToList();
        }

        public Artist GetById(int id)
        {
            throw new NotImplementedException();
        }

        public bool Remove(Artist entity)
        {
            throw new NotImplementedException();
        }

        public bool Update(Artist entity)
        {
            throw new NotImplementedException();
        }
    }
}
